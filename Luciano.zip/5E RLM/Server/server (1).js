const WebSocket = require('ws');


const wsServer = new WebSocket.Server({
    port: 5000,
});
console.log("Il Server è attivo e aspetta pacchetti sulla porta " + wsServer.options.port );


var operation = "x2";


wsServer.on("connection" , (socket) => {
    console.log("un client si è appena connesso, i dati del client sono:\n" + socket);
    socket.send("la tua connessione è stata accettata dal server");
    socket.on("message" , (msg) => {
        msg = ''+msg;
        console.log("ho ricevuto un messaggio: " + msg);
        if (isNaN(msg*1)) {
            let upd = "";
            switch (msg) {
                case "moltiplica":
                    operation = "mul";
                    break;
                case "raddoppia":
                    operation = "x2";
                    break;
                case "fattoriale":
                    operation = "fat";
                    break;
                default:
                    upd += "Operazione non valida";
                    break;
            }
            socket.send(upd+ "\nmessaggio ricevuto");
        } else {
            socket.send(loco(msg));
        }
    });
});


function loco(stringa) {
    var _op = operation;
    let numero = parseInt(stringa);
    switch (_op) {
        case "mul":
            return numero*numero;
        case "x2":
            return numero*2;
        case "fat":
            return calcFact(numero);
        default:
            break;
    }
}


function calcFact( num ){
    var fact = 1;
    for(let i = 1; i <= num; i++)
    {
        fact = fact * i;
    }
    return fact;
}

